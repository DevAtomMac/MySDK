//
//  MySDK.h
//  MySDK
//
//  Created by Salman  Ahmed on 18/04/2018.
//  Copyright © 2018 test. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MySDK.
FOUNDATION_EXPORT double MySDKVersionNumber;

//! Project version string for MySDK.
FOUNDATION_EXPORT const unsigned char MySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MySDK/PublicHeader.h>


